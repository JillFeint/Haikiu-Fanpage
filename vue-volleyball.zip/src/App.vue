<template>
  <div>
    <header class="header">
      <div class="div-logo">
        <img class="logo" src="./assets/logo.png" alt="">
      </div>
      <nav class="nav">
        <div class="div-header">
          <ul class="ul-nav">
            <li class="btn-header"><a href="#">Inicio</a></li>
            <li class="btn-header"><a href="#">Contactanos</a></li>
            <li class="btn-header"><a href="#">Equipo</a></li>
            <li class="btn-header"><a href="#">Partidos</a></li>
            <li class="btn-header"><a href="#">Informacion</a></li>
          </ul>
        </div>
        <section>
          
        </section>
        <footer></footer>
      </nav>
    </header>
  </div>
</template>

<script>
export default {

}
</script>

<style>
* {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
}
.header {
  width: 100%;
  height: 32vh;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-image: url("./assets/header.png");
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center center;
  margin: 0;
  padding: 0; 
  box-sizing: border-box; 
}
.div-logo {
  display: flex;
  justify-content: flex-start;
  align-items: center;
}
.logo {
  width: 100px;
  height: 150px;
}
.ul-nav {
  list-style: none;
  display: flex;
}
.btn-header {
  margin: 1em;
}
.btn-header a {
  text-decoration: none;
  color: white;
  font-size: 20px;
}
.btn-header a:hover{
  background-color: orangered;
  padding: 5px;
  border-radius: 5px;
  transform:translateY(-5px);
  transform: scale(1.2); 
}


</style>
